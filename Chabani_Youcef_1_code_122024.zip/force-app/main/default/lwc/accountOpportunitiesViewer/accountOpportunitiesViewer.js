import { LightningElement, api, wire, track } from 'lwc';
import getOpportunities from '@salesforce/apex/AccountOpportunitiesController.getOpportunities';
import { refreshApex } from '@salesforce/apex'; // Import pour rafraîchir les données    handleRefresh() {
    


export default class AccountOpportunitiesViewer extends LightningElement {
    @api recordId; // Identifiant du compte transmis au composant
    @track opportunities = [];  //// Liste des opportunités récupérées
    @track siOpportunities = false; // Nouvelle propriété pour vérifier les opportunités
        @track error = {}; // Stocke les éventuelles erreurs
   
   wiredOpportunitiesResult;
    columns = [
        { label: 'Nom Opportunité', fieldName: 'Name', type: 'text' },
        { label: 'Montant', fieldName: 'Amount', type: 'currency' },
        { label: 'Date de Clôture', fieldName: 'CloseDate', type: 'date' },
        { label: 'Phase', fieldName: 'StageName', type: 'text' }
    ];
     // Colonnes définies pour le tableau des opportunités
    @wire(getOpportunities, { accountId: '$recordId' }) //error
    wiredOpportunities(resultat) {
        this.wiredOpportunitiesResult=resultat;
const {data , error}=resultat;
              if (data) {
                    // Récupération des opportunités via un appel Apex
            this.opportunities = data;
            this.siOpportunities = data.length > 0;  // Vérifie si le tableau n'est pas vide
            this.error=null;
        } else if (error) {
                        // En cas d'erreur, stockez-la pour un affichage
            this.error = error;
            this.opportunities = [];    
            this.siOpportunities = false;
                }
        
        
        }
        handleRafraichir(){ //methode permettant de rafraichir les données 
            
            refreshApex(this.wiredOpportunitiesResult);
        }
        

}